package com.example.mohit.moziosampleapp.Fragment;


import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.transition.TransitionInflater;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import com.example.mohit.moziosampleapp.Interface.Communicator;
import com.example.mohit.moziosampleapp.Utils.Helper;
import com.example.mohit.moziosampleapp.Activity.MainActivity;
import com.example.mohit.moziosampleapp.Objects.Patient;
import com.example.mohit.moziosampleapp.R;
import com.example.mohit.moziosampleapp.databinding.FragmentHomeBinding;

import java.util.List;


public class HomeFragment extends Fragment {
    public static String  TAG_FRAGMENT = "homefragmenttag";

    private List<Patient> patientList;
    private FragmentHomeBinding fragmentHomeBinding;
    private Communicator communicator;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        fragmentHomeBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_home,container,false);
        initalise();
        return fragmentHomeBinding.getRoot();
    }

    private void initalise() {
        Helper.log("Initialising");
        communicator = (MainActivity)getActivity();
        patientList = Helper.getOldPatient(getContext());
        String[] patients = new String[patientList.size()];
        for(int i = 0; i < patients.length;i++) {
            patients[i] = patientList.get(i).getName();
            Helper.log(patients[i]);
        }
        fragmentHomeBinding.lvPatientList.setAdapter(new ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1,patients));
        fragmentHomeBinding.lvPatientList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Helper.currentPatient = patientList.get(adapterView.getPositionForView(view));
                loadAddingPatientFragment();
            }
        });
        fragmentHomeBinding.fabAddPatient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Helper.currentPatient = null;
                loadAddingPatientFragment();
            }
        });
    }

    private void loadAddingPatientFragment() {
        AddingPatientFragment addingPatientFragment = new AddingPatientFragment();
        addingPatientFragment.setEnterTransition(TransitionInflater.from(getContext()).inflateTransition(android.R.transition.slide_bottom));
        addingPatientFragment.setReturnTransition(TransitionInflater.from(getContext()).inflateTransition(android.R.transition.slide_bottom));
        communicator.loadFragment(addingPatientFragment,AddingPatientFragment.TAG_FRAGMENT,true);
    }

}
