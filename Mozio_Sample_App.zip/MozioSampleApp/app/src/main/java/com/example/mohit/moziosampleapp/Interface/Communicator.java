package com.example.mohit.moziosampleapp.Interface;

import android.support.v4.app.Fragment;

/**
 * Created by E069817 on 6/30/2017.
 */

public interface Communicator {
    public void loadFragment(Fragment fragment,String tag, boolean addToBackstack);
}
