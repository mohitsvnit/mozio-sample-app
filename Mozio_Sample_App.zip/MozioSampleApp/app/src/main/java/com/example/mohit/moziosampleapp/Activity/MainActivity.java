package com.example.mohit.moziosampleapp.Activity;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;

import com.example.mohit.moziosampleapp.Interface.Communicator;
import com.example.mohit.moziosampleapp.Fragment.HomeFragment;
import com.example.mohit.moziosampleapp.R;

public class MainActivity extends AppCompatActivity implements Communicator {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        loadFragment(new HomeFragment(),HomeFragment.TAG_FRAGMENT,false);
    }

    @Override
    public void loadFragment(Fragment fragment, String tag, boolean addToBackstack) {
        if(getSupportFragmentManager().findFragmentByTag(tag) != null){
            fragment = getSupportFragmentManager().findFragmentByTag(tag);
        }

        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        if(addToBackstack){
            fragmentTransaction.addToBackStack(tag);
        }
        fragmentTransaction.replace(R.id.mainActivity,fragment,tag);
        fragmentTransaction.commitAllowingStateLoss();
    }
}
