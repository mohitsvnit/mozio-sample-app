package com.example.mohit.moziosampleapp.Objects;

import java.util.List;

/**
 * Created by E069817 on 6/30/2017.
 */

public class Patient {
    private String name;
    private String gender;
    private int age;
    private List<String> symtoms;
    private String expectedDisease;
    private String drugUsage;


    public String getDrugUsage() {
        return drugUsage;
    }

    public void setDrugUsage(String drugUsage) {
        this.drugUsage = drugUsage;
    }

    public static String GENDER_MALE = "Male";
    public static String GENDER_FEMALE = "Female";
    public static String GENDER_OTHER = "Other";


    public String getExpectedDisease() {
        return expectedDisease;
    }

    public void setExpectedDisease(String expectedDisease) {
        this.expectedDisease = expectedDisease;
    }

    public Patient(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public List<String> getSymtoms() {
        return symtoms;
    }

    public void setSymtoms(List<String> symtoms) {
        this.symtoms = symtoms;
    }
}
