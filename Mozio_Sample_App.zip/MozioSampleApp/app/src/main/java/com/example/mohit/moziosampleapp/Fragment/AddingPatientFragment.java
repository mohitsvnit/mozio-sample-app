package com.example.mohit.moziosampleapp.Fragment;


import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.mohit.moziosampleapp.Interface.Communicator;
import com.example.mohit.moziosampleapp.Utils.Helper;
import com.example.mohit.moziosampleapp.Activity.MainActivity;
import com.example.mohit.moziosampleapp.Objects.Patient;
import com.example.mohit.moziosampleapp.R;
import com.example.mohit.moziosampleapp.Objects.Server;
import com.example.mohit.moziosampleapp.databinding.FragmentAddingPatientBinding;

import java.util.ArrayList;
import java.util.List;


public class AddingPatientFragment extends Fragment {
    public static String TAG_FRAGMENT = "AddingPatientFragmentTag";
    private Dialog selectSymptomsDialog;
    private List<String> selectedSymptoms;
    private FragmentAddingPatientBinding fragmentAddingPatientBinding;
    private Patient currentPatient;
    private ProgressDialog progressDialog;
    private Communicator communicator;

    public AddingPatientFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        fragmentAddingPatientBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_adding_patient,container,false);
        initialise();
        return fragmentAddingPatientBinding.getRoot();
    }

    private void initialise() {
        communicator = (MainActivity) getActivity();
        selectedSymptoms = new ArrayList<>();
        fragmentAddingPatientBinding.spnGender.setAdapter(new ArrayAdapter<String>(getContext(),android.R.layout.simple_spinner_dropdown_item, Server.gender));
        fragmentAddingPatientBinding.spnDrugsUsage.setAdapter(new ArrayAdapter<String>(getContext(),android.R.layout.simple_spinner_dropdown_item,Server.drugType));

        if (Helper.currentPatient != null){
            currentPatient = Helper.currentPatient;
            selectedSymptoms = currentPatient.getSymtoms();
            fragmentAddingPatientBinding.setPatient(Helper.currentPatient);
            for(int i = 0; i < Server.gender.length; i++){
                if(currentPatient.getGender().equals(Server.gender[i])){
                    fragmentAddingPatientBinding.spnGender.setSelection(i,true);
                    break;
                }
            }
            for(int i = 0; i < Server.drugType.length; i++) {
                if(currentPatient.getDrugUsage().equals(Server.drugType[i])){
                    fragmentAddingPatientBinding.spnDrugsUsage.setSelection(i,true);
                    break;
                }
            }

            updateSelectSymptoms();

        }
        initialiseSelectSymptomsDialog();
        initialiseProgressBar();

        fragmentAddingPatientBinding.tvSymptoms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectSymptomsDialog.show();
            }
        });
        fragmentAddingPatientBinding.btnSavePatient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Helper.savePatient(getContext(),currentPatient);
                communicator.loadFragment(new HomeFragment(),HomeFragment.TAG_FRAGMENT,false);
            }
        });
    }

    private void initialiseProgressBar() {
        progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Processing Symptoms...");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
    }

    private void startProgressbar() {
        if(progressDialog != null) {
            if(!progressDialog.isShowing()){
                progressDialog.show();
            }
        }
    }

    private void dismissProgressBar() {
        if(progressDialog != null) {
            if(progressDialog.isShowing()) {
                progressDialog.dismiss();
            }
        }
    }

    private void initialiseSelectSymptomsDialog() {
        LayoutInflater layoutInflater = LayoutInflater.from(getContext());
        selectSymptomsDialog = new Dialog(getContext());
        selectSymptomsDialog.setTitle("SelectSymptoms");
        View view = layoutInflater.inflate(R.layout.dialog_multiselect,null);
        LinearLayout llMultiSelect = view.findViewById(R.id.llMultiSelect);
        for(int i = 0; i < Server.symptoms.length; i++) {
            View row = layoutInflater.inflate(R.layout.row_multiselect_item,null);
            final TextView tvSymptomName = row.findViewById(R.id.tvSymptomsName);
            final CheckBox checkBox = row.findViewById(R.id.cbSymptomCheck);
            tvSymptomName.setText(Server.symptoms[i]);
            if(selectedSymptoms.contains(Server.symptoms[i])){
                checkBox.setChecked(true);
            }
            checkBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(checkBox.isChecked()) {
                        selectedSymptoms.add(tvSymptomName.getText().toString());
                    }else{
                        selectedSymptoms.remove(tvSymptomName.getText().toString());
                    }
                }
            });
            llMultiSelect.addView(row);
            Helper.log("View Added: " + String.valueOf(i));
        }

        selectSymptomsDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                updateSelectSymptoms();
                updatePatient();
                predictDisease();
            }
        });
        Button btnUpdateSymptoms = view.findViewById(R.id.btnUpdateSymptoms);
        btnUpdateSymptoms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               selectSymptomsDialog.dismiss();
            }
        });
        selectSymptomsDialog.setContentView(view);
    }

    private void updateSelectSymptoms() {
        String allSymptoms = "";
        if(selectedSymptoms.size() == 0) {
            allSymptoms = "Add Symptoms";
        }else {

            for (int i = 0; i < selectedSymptoms.size(); i++) {
                if (i != selectedSymptoms.size() - 1) {
                    allSymptoms += (selectedSymptoms.get(i) + ",");
                } else {
                    allSymptoms += selectedSymptoms.get(i);
                }

            }
        }

        fragmentAddingPatientBinding.tvSymptoms.setText(allSymptoms);
    }

    private void updatePatient() {
        try {
            currentPatient = new Patient(fragmentAddingPatientBinding.etFullName.getText().toString());
            currentPatient.setAge(Integer.parseInt(fragmentAddingPatientBinding.etAge.getText().toString()));
            currentPatient.setGender(fragmentAddingPatientBinding.spnGender.getSelectedItem().toString());
            currentPatient.setSymtoms(selectedSymptoms);
            currentPatient.setDrugUsage(fragmentAddingPatientBinding.spnDrugsUsage.getSelectedItem().toString());
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private void predictDisease() {
        startProgressbar();
        String result = "";
        result += checkForToddsSyndrome(currentPatient);
        final String finalResult = result;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        dismissProgressBar();
                        fragmentAddingPatientBinding.tvExpectedDisease.setText(finalResult);
                        currentPatient.setExpectedDisease(finalResult);
                    }
                });
            }
        }).start();
    }

    public String checkForToddsSyndrome(Patient patient) {
        int probability = 0;
        if(patient.getAge() < 15)
            probability+=25;
        if(patient.getGender().equals(Patient.GENDER_MALE))
            probability+=25;
        if(patient.getSymtoms().contains("Migrains"))
            probability+=25;
        if(patient.getDrugUsage().equals("Hallucinogenic"))
            probability+=25;

        return "Todd's Syndrome("+String.valueOf(probability)+"%)";

    }

}
