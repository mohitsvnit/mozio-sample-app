package com.example.mohit.moziosampleapp.Utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.example.mohit.moziosampleapp.Objects.Patient;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by E069817 on 6/30/2017.
 */

public class Helper {
    public static Patient currentPatient;
    public static String KEY_SHARED_PREFERENCE = "MozioSampleAppSharedKey";
    public static String KEY_PATIENT_SHARED_DATA = "patientsstored";
    public static void log(String msg) {
        Log.e("mohitDebugger",msg);
    }

    public static List<Patient> getOldPatient(Context context) {
        List<Patient> patientList = new ArrayList<>();
        SharedPreferences sharedPreferences = context.getSharedPreferences(KEY_SHARED_PREFERENCE,Context.MODE_PRIVATE);
        String data = sharedPreferences.getString(KEY_PATIENT_SHARED_DATA,null);
        Helper.log("Data: " + data);
        if(data != null) {
            try {
                JSONArray jsonArray = new JSONArray(data);
                for(int i = 0; i < jsonArray.length(); i++) {
                    patientList.add(new Gson().fromJson(jsonArray.get(i).toString(),Patient.class));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return patientList;
    }

    public static void savePatient(Context context,Patient patient) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(KEY_SHARED_PREFERENCE,Context.MODE_PRIVATE);
        List<Patient> patientList = getOldPatient(context);
        boolean flag = false;
        for(int i = 0; i < patientList.size(); i++) {
            if(patientList.get(i).getName().equals(patient.getName())){
                patientList.remove(i);
                patientList.add(patient);
                flag = true;
            }
        }
        if(!flag)
            patientList.add(patient);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String data = new Gson().toJson(patientList);
        Helper.log("Data to save: " + data);
        editor.putString(KEY_PATIENT_SHARED_DATA,data);
        Helper.log(String.valueOf(editor.commit()));

    }
}
