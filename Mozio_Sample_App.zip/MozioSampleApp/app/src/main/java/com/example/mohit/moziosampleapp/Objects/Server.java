package com.example.mohit.moziosampleapp.Objects;

import android.util.Log;

/**
 * Created by E069817 on 6/30/2017.
 */

public class Server {
    public static String[] symptoms = {"Head Ache","Migrains", "Stomach Pain","Back Ache", "BodyPain", "Weekness", "Vomiting"};
    public static String[] gender = {"Not Selected","Male","Female","Other"};
    public static String[] drugType = {"None", "Toxic", "Hallucinogenic"};
}
